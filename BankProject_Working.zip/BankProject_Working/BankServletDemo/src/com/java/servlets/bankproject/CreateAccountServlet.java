package com.java.servlets.bankproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreateAccountServlet
 */
public class CreateAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		Account account = new Account();
		RequestDispatcher disp1 = request.getRequestDispatcher("Menu.html");
		disp1.include(request, response);
		account.setFirstName(request.getParameter("firstName"));
		account.setLastName(request.getParameter("lastName"));
		account.setCity(request.getParameter("city"));
		account.setState(request.getParameter("state"));
		int amount = Integer.parseInt(request.getParameter("amount"));
		account.setAmount(amount);
		account.setCheqFacil(request.getParameter("cheqFacil"));
		account.setAccountType(request.getParameter("accountType"));
		AccountDAO dao = new AccountDAO();
		
		try {
			out.println("<br/><br/>" +dao.createAccount(account));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
