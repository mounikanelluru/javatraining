package com.java.servlets.bankproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

	Connection con;
	PreparedStatement pst;
	public int authenticate(String user, String pwd) throws SQLException {
		con = ConnectionHelper.getConnection();
		String cmd = "select count(*) cnt from BankUser where UserName=? AND Passcode=?";
		pst = con.prepareStatement(cmd);
		pst.setString(1, user);
		pst.setString(2, pwd);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int count = rs.getInt("cnt");
		return count;
	}
}
